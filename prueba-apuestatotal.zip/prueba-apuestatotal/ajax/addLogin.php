<?php

if(!empty($_POST)){
	if(isset($_POST["idusuario"]) &&isset($_POST["clave"])){
		if($_POST["idusuario"]!=""&&$_POST["clave"]!=""){
			include("db_connection.php");

		 	$idusuario = $_POST['idusuario'];
		 	$clave = $_POST['clave'];
		 
	 
			 $user_id=null;
			 $user_tp=null;

			$sql1= "select * from tb_usuarios where nombre='$idusuario'  and clave='$clave' ";
			$query = $con->query($sql1);
			while ($r=$query->fetch_array()) {
				$user_id=$r["id"];
				$user_tp=$r["tipo_usu"];
				break;
			}
			if($user_id==null){
				print "<script>alert(\"Acceso invalido.\");window.location='../index.php';</script>";
			}else{
				session_start();
				$_SESSION["user_id"]=$user_id;

				if($user_tp==1){
					print "<script>window.location='../panelmaster.php';</script>";	
				}else{
					print "<script>window.location='../panel.php';</script>";				
				}
							
			}
		}
	}
}



?>