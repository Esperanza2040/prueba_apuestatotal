<?php
// include Database connection file
include("db_connection.php");

// check request
if(isset($_POST))
{
    // get values
    $id = $_POST['id'];
	$monto=$_POST['monto'];
	$banco= strtoupper($_POST['banco']);
   
   
    $canal = strtoupper($_POST['canal']);


    // Updaste User details
    $query = "UPDATE tb_trans_recarg SET status='1' WHERE id = '$id'";
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }

    $queryc=mysqli_query($con,"select * from tb_trans_recarg where id='".$id."'");
    $rwc =mysqli_fetch_array($queryc);
    $id_cliente=$rwc['id_cliente'];

    $querys=mysqli_query($con,"select * from tb_saldos where id_cliente='".$id_cliente."'");
		$rws =mysqli_fetch_array($querys);
		$saldo=$rws['saldo'];
		$new_saldo= ($saldo + $monto);

		$queryu=mysqli_query($con,"UPDATE tb_saldos set saldo=$new_saldo where id_cliente='".$id_cliente."'");
        if (!$result = mysqli_query($con, $queryu)) {
	        exit(mysqli_error($con));
	    }
}