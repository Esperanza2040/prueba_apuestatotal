<?php
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
	print "<script>alert(\"Acceso invalido!\");window.location='index.php';</script>";
}

?>
<?php
	// include Database connection file 
	include("db_connection.php");
	$promo_actual = $_SESSION["user_id"];
	// Design initial table header 
	$data = '<table class="table table-bordered table-striped">
						<tr>
							<th>No.</th>
							<th>Promotor</th>
							<th>PlayerID</th>
							<th>Voucher</th>
							<th>Monto</th>
							<th>Banco</th>
							<th>Canal</th>
							<th>Fecha</th>
							<th></th>
							<th></th>
						</tr>';

	$query = "SELECT * FROM tb_trans_recarg where status=0 and id_promo <> '$promo_actual'";

	if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }

    // if query results contains rows then featch those rows 
    if(mysqli_num_rows($result) > 0)
    {
    	$number = 1;
    	while($row = mysqli_fetch_assoc($result))
    	{
			$id_promo=$row['id_promo'];
			$id_cliente=$row['id_cliente'];
			$queryp = "SELECT * FROM tb_usuarios where id='$id_promo'";
			$resultp = mysqli_query($con, $queryp);
			$rowp = mysqli_fetch_assoc($resultp);

			$queryc = "SELECT * FROM tb_usuarios where id='$id_cliente'";
			$resultc = mysqli_query($con, $queryc);
			$rowc = mysqli_fetch_assoc($resultc);

    		$data .= '<tr>
				<td>'.$number.'</td>
				<td> <strong>'.$rowp['nombre'].'</strong></td>				
				<td>'.$rowc['codigo'].'</td>  
				<td> <img src="ajax/readVista.php?id='.$row['id'].'" width="250"/></td>
				<td>'.$row['monto'].'</td>
				<td>'.$row['banco'].'</td>
				<td>'.$row['canal'].'</td>
				<td>'.$row['fecha_registro'].'</td>
				<td>
					<button onclick="GetAprobarRecarga('.$row['id'].')" class="btn btn-success"><i class="fas fa-check"></i></button>
				</td>
				<td>
				
					<button onclick="GetObsRecarga('.$row['id'].')" class="btn btn-danger"><i class="fas fa-exclamation-triangle"></i></button>
				</td>
    		</tr>';
    		$number++;
    	}
    }
    else
    {
    	// records now found 
    	$data .= '<tr><td colspan="6">No hay registros!</td></tr>';
    }

    $data .= '</table>';

    echo $data;
?>