<?php
	if(isset($_POST['idplayer']))
	{

		$revisar = getimagesize($_FILES["voucher"]["tmp_name"]);
    if($revisar !== false){
        $image = $_FILES['voucher']['tmp_name'];
        $voucher = addslashes(file_get_contents($image));

		// include Database connection file 
		include("db_connection.php");

		// get values 
		$idplayer = $_POST['idplayer'];
		 
		$monto = $_POST['monto'];
		$banco = strtoupper($_POST['banco']);
		$canal = strtoupper($_POST['canal']); 
		$id_promo = $_POST['id_promo'];
  
		 
		$query=mysqli_query($con,"select * from tb_usuarios where codigo='".$idplayer."'");
		$rw =mysqli_fetch_array($query);
		$id_cliente=$rw['id'];

		$query = "INSERT INTO tb_trans_recarg(id_cliente, id_promo, monto, banco, voucher, canal, fecha_registro, status) 
		VALUES('$id_cliente', '$id_promo', '$monto', '$banco', '$voucher', '$canal', now(), '0')";
		if (!$result = mysqli_query($con, $query)) {
	        exit(mysqli_error($con));
	    }
	   // echo "1 Record Added!";
		print "<script>window.location='../panelmaster.php';</script>";	

	}else{
        echo "Por favor seleccione imagen a subir.";
    }
	}
?>