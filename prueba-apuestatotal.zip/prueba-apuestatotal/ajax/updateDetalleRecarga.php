<?php
// include Database connection file
include("db_connection.php");

// check request
if(isset($_POST))
{
    // get values
    $id = $_POST['id'];
	$monto=$_POST['monto'];
	$banco= strtoupper($_POST['banco']);
   
   
    $canal = strtoupper($_POST['canal']);


    // Updaste User details
    $query = "UPDATE tb_trans_recarg SET monto='$monto', banco='$banco', canal = '$canal', status = '0' WHERE id = '$id'";
    if (!$result = mysqli_query($con, $query)) {
        exit(mysqli_error($con));
    }

     
}