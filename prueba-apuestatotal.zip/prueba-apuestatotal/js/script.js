// Add Record
function addRecord() {
    // get values
    var idalumno = $("#idalumno").val();
    var codalumno = $("#codalumno").val();
    var codmatri = $("#codmatri").val();
    var obs = $("#obs").val();

    // Add record
    $.post("ajax/addRecord.php", {
        idalumno: idalumno,
        codalumno: codalumno,
        codmatri: codmatri,
		obs: obs
    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");

        // read records again
        readRecords();

        // clear fields from the popup
        $("#idalumno").val("");
        $("#codalumno").val("");
        $("#codmatri").val("");
        $("#obs").val("");
    });
}


function addRecordPlayer() {
    // get values
    
    var idplayer = $("#idplayer").val();
    var voucher = $("#voucher").val();
    var monto = $("#monto").val();
    var banco = $("#banco").val();
    var canal = $("#canal").val();
    var id_promo = $("#id_promo").val();

    // Add record
    $.post("ajax/addRecordPlayer.php", {
        idplayer: idplayer,
        voucher: voucher,
        monto: monto,
		banco: banco,
        canal: canal,
        id_promo: id_promo

    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");

        // read records again
        readVerificar();

        // clear fields from the popup
        $("#idplayer").val("");
        $("#voucher").val("");
        $("#monto").val("");
        $("#banco").val("");
        $("#canal").val("");
        $("#id_promo").val("");
    });
}


//   Login
function addLogin() {
    // get values
    var idusuario = $("#idusuario").val();
    var clave = $("#clave").val();
 

    // Add record
    $.post("ajax/addLogin.php", {
        idusuario: idusuario,
        clave: clave
        
    }, function (data, status) {
        // close the popup
        $("#add_new_record_modal").modal("hide");

        // read records again
        readRecords();

        // clear fields from the popup
        $("#idusuario").val("");
        $("#clave").val("");
     
    });
}

// READ records
function readRecords() {
    $.get("ajax/readRecord.php", {}, function (data, status) {
        $("#records_content").html(data);
    });
}

function readVerificar() {
    $.get("ajax/readVerificar.php", {}, function (data, status) {
        $("#verificar_registros").html(data);
    });
}

function readVerificarPromo() {
    $.get("ajax/readVerificarPromo.php", {}, function (data, status) {
        $("#promotor_registros").html(data);
    });
}

 

function addbuscarplayer() {
    // get values
    var id = $("#idplayer").val();
    
    
    $.post("ajax/AddBuscarPlayer.php", {
        id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            console.log(user);
            // Assing existing values to the modal popup fields
            $("#nombre").val(user.nombre);
            if ( user.status == 200) { alert ("No se encontro registro"); }
           
        }
    );
    // Open modal popup
    $("#add_new_record_modal").modal("show");
}

function DeleteUser(id) {
    var conf = confirm("¿Está seguro, realmente desea eliminar el registro?");
    if (conf == true) {
        $.post("ajax/deleteUser.php", {
                id: id
            },
            function (data, status) {
                // reload Users by using readRecords();
                readRecords();
            }
        );
    }
}

function GetUserDetails(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readUserDetails.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_idalumno").val(user.idalumno);
            $("#update_codalumno").val(user.codalumno);
            $("#update_obs").val(user.obs);
        }
    );
    // Open modal popup
    $("#update_user_modal").modal("show");
}


function GetAprobarRecarga(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readAprobarRecarga.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_idalumno").val(user.monto);
            $("#update_codalumno").val(user.banco);
            $("#update_obs").val(user.canal);
        }
    );
    // Open modal popup
    $("#update_user_modal").modal("show");
}

function GetObsRecarga(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readObsRecarga.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            var user = JSON.parse(data);
            // Assing existing values to the modal popup fields
            $("#update_monto").val(user.monto);
            $("#update_banco").val(user.banco);
            $("#update_canal").val(user.canal);
        }
    );
    // Open modal popup
    $("#update_obser_modal").modal("show");
}

function GetDetalleRecarga(id) {
    // Add User ID to the hidden field for furture usage
    $("#hidden_user_id").val(id);
    $.post("ajax/readDetalleRecarga.php", {
            id: id
        },
        function (data, status) {
            // PARSE json data
            
    
            var user = JSON.parse(data);
            console.log(user);
            // Assing existing values to the modal popup fields
            $("#update_monto").val(user.monto);
            $("#update_banco").val(user.banco);
            $("#update_canal").val(user.canal);
        }
    );
    // Open modal popup
    $("#update_user_modal").modal("show");
}


function UpdateAprobarRecarga() {
    // get values
    var monto = $("#update_idalumno").val();
    var banco = $("#update_codalumno").val();
    var canal = $("#update_obs").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateAprobarRecarga.php", {
            id: id,
            monto: monto,
            banco: banco,
            canal: canal
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            // reload Users by using readRecords();
            readVerificar();
        }
    );
}

function UpdateObsRecarga() {
    // get values
    var monto = $("#update_idalumno").val();
    var banco = $("#update_codalumno").val();
    var canal = $("#update_obs").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateObsRecarga.php", {
            id: id,
            monto: monto,
            banco: banco,
            canal: canal
        },
        function (data, status) {
            // hide modal popup
            $("#update_obser_modal").modal("hide");
            // reload Users by using readRecords();
            readVerificar();
        }
    );
}

function UpdateUserDetails() {
    // get values
    var idalumno = $("#update_idalumno").val();
    var codalumno = $("#update_codalumno").val();
    var obs = $("#update_obs").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateUserDetails.php", {
            id: id,
            idalumno: idalumno,
            codalumno: codalumno,
            obs: obs
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            // reload Users by using readRecords();
            readRecords();
        }
    );
}


function UpdateDetalleRecarga() {
    // get values
    var monto = $("#update_monto").val();
    var banco = $("#update_banco").val();
    var canal = $("#update_canal").val();

    // get hidden field value
    var id = $("#hidden_user_id").val();

    // Update the details by requesting to the server using ajax
    $.post("ajax/updateDetalleRecarga.php", {
            id: id,
            monto: monto,
            banco: banco,
            canal: canal
        },
        function (data, status) {
            // hide modal popup
            $("#update_user_modal").modal("hide");
            // reload Users by using readRecords();
            readVerificarPromo();
        }
    );
}

 