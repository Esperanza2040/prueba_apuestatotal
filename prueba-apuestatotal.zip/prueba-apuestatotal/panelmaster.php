<?php 
session_start();
if(!isset($_SESSION["user_id"]) || $_SESSION["user_id"]==null){
	print "<script>alert(\"Acceso invalido!\");window.location='index.php';</script>";
}

include("ajax/db_connection.php");
$id_promo=$_SESSION["user_id"]; 
			$queryp = "SELECT * FROM tb_usuarios where id='$id_promo'";
			$resultp = mysqli_query($con, $queryp);
			$rowp = mysqli_fetch_assoc($resultp);
?>

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">
<title>Prueba | Apuesta Total</title>

<!-- Bootstrap core CSS -->
<link href="dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="assets/sticky-footer-navbar.css" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous"></head>
<Style> 
.text {
  font-size:25px;
  font-family:helvetica;
  font-weight:bold;
  color:#e30713;
  text-transform:uppercase;
}
.parpadea {
  
  animation-name: parpadeo;
  animation-duration: 4s;
  animation-timing-function: linear;
  animation-iteration-count: infinite;

  -webkit-animation-name:parpadeo;
  -webkit-animation-duration: 4s;
  -webkit-animation-timing-function: linear;
  -webkit-animation-iteration-count: infinite;
}

@-moz-keyframes parpadeo{  
  0% { opacity: 1.0; }
  50% { opacity: 0.0; }
  100% { opacity: 1.0; }
}

@-webkit-keyframes parpadeo {  
  0% { opacity: 1.0; }
  50% { opacity: 0.0; }
   100% { opacity: 1.0; }
}

@keyframes parpadeo {  
  0% { opacity: 1.0; }
   50% { opacity: 0.0; }
  100% { opacity: 1.0; }
}
</Style>

<body>
<header> 
  <!-- Fixed navbar -->
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark"> <a class="navbar-brand" href="#"><img src="img/logo.jpg" style="width: 25%; height: 25%;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
      <li class="nav-item active"> <a class="nav-link" href="panelmaster.php">Inicio<span class="sr-only">(current)</span></a> </li>
        <li class="nav-item active"> <a class="nav-link" href="misregistros.php">Historico de Recargas <span class="sr-only">(current)</span></a> </li>
         </ul>
      <form class="form-inline mt-2 mt-md-0">
      <a type="button" class="btn btn-outline-success my-2 my-sm-0"href="./ajax/addLogout.php">SALIR</a>
        
      </form>
    </div>
  </nav>
</header>

<!-- Begin page content -->

<div class="container">
  <h3 class="mt-5">Panel para Promotores de  <span style="color:red"> <?php echo $rowp['nombre'] ?> </span> </h3>
  <hr>
  <div class="row">
    <div class="col-12 col-md-12"> 
      <!-- Contenido -->
      
      
      
<!-- Content Section --> 
<!-- crud jquery-->
<div class="da">
  <div class="row">
    <div class="col-md-12">
      <div class="pull-right">
        <button class="btn btn-warning" data-toggle="modal" data-target="#add_new_record_modal">Registrar Recarga</button>
      </div>
    </div>
  </div>
  <br>
  <div class="row">
  
    <div class="col-md-12">
    <h5  class="parpadea text">Ultimas recargas registradas por verificar</h5>
      <div id="verificar_registros"></div>
    </div>
  </div>
</div>
<!-- /Content Section --> 

<!-- Bootstrap Modals --> 
<!-- Modal - Add New Record/User -->
<div class="modal fade" id="add_new_record_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-header">
        <h5 class="modal-title">Registrar Recarga</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
      
      
      <div class="modal-body">
      <form name="MiForm" id="MiForm" method="post" action="ajax/addRecordPlayer.php" enctype="multipart/form-data">


      <label for="Cod ALumno">PlayerID</label>
        <div class="input-group mb-3">        
          <input type="text" class="form-control"  name="idplayer" id="idplayer" aria-label="Recipient's username" aria-describedby="button-addon2">
         <div class="input-group-append">
            <button class="btn btn-outline-secondary" onclick="addbuscarplayer();" type="button" id="button-addon2"><img src="img/buscar.jpg" style="width: 20px; height: 20px;">	</button>
          </div>
        </div>

        <div class="form-group">
          <label for="Monto">Nombre</label>
          <input type="text" name="nombre"  id="nombre" class="form-control" value="" readonly/>
        </div>
        <div class="form-group">
          <label for="Cod ALumno">Voucher</label>
    
          <input type="file" class="form-control" id="voucher" name="voucher" multiple>
        </div>
        <div class="form-group">
          <label for="Monto">Monto</label>
          <input type="text" name="monto"  id="monto" class="form-control" value=""/>
        </div>
        <div class="form-group">
          <label for="banco">Banco</label>
          <!--<textarea style="text-transform:uppercase" id="banco" class="form-control"></textarea>-->
          <input type="text" name="banco" id="banco" class="form-control" value=""/> 
        </div>
        <div class="form-group">
          <label for="Monto">Canal</label>
          <input type="text" id="canal" name="canal" class="form-control" value=""/>
          <input type="hidden" id="id_promo" name="id_promo" class="form-control" value="<?php echo $_SESSION["user_id"];?>"/>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Agregar</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!-- // Modal --> 

<!-- Modal - Update User details -->
<div class="modal fade" id="update_user_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-header">
        <h5 class="modal-title">Aprobar Recarga</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div> 
      
      
      <div class="modal-body">
        <div class="form-group">
          <label for="idalumno">Monto</label>
          <input type="text" id="update_idalumno"   class="form-control" readonly/>
        </div>
        <div class="form-group">
          <label for="codalumno">Banco</label>
          <input type="text" id="update_codalumno" class="form-control" readonly/>
        </div>
        <div class="form-group">
          <label for="obs">Canal</label>
          <input type="text" id="update_obs"  class="form-control" readonly/>
        
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="UpdateAprobarRecarga()" >Aprobar</button>
        <input type="hidden" id="hidden_user_id">
      </div>
    </div>
  </div>
</div>
<!-- // Modal --> 

<!-- Modal - Update User details -->
<div class="modal fade" id="update_obser_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
   
      <div class="modal-header">
        <h5 class="modal-title">Rechazar Recarga</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div> 
      
      
      <div class="modal-body">
        <div class="form-group">
          <label for="idalumno">Monto</label>
          <input type="text" id="update_monto"   class="form-control" readonly/>
        </div>
        <div class="form-group">
          <label for="codalumno">Banco</label>
          <input type="text" id="update_banco" class="form-control" readonly/>
        </div>
        <div class="form-group">
          <label for="obs">Canal</label>
          <input type="text" id="update_canal"  class="form-control" readonly/>
        
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="UpdateObsRecarga()" >Observar</button>
        <input type="hidden" id="hidden_user_id">
      </div>
    </div>
  </div>
</div>
<!-- // Modal --> 

<!-- Jquery JS file --> 
<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<!-- Bootstrap JS file --> 
<!-- Custom JS file --> 
<script type="text/javascript" src="js/script.js"></script> 
<!-- Fin crud jquery-->

<script>
  $(document).ready(function () {
    // READ recods on page load
    readVerificar(); // calling function
});
</script> 

      <!-- Fin Contenido --> 
    </div>
  </div>
  <!-- Fin row --> 
  
</div>
<!-- Fin container -->
<footer class="footer">
  <div class="container"> <span class="text-muted">
     
    </span> </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== --> 
<script src="dist/js/bootstrap.min.js"></script> 

<!-- Placed at the end of the document so the pages load faster -->

</body>
</html>